/* Global Variables */
let baseURL = 'http://api.openweathermap.org/data/2.5/forecast?id=';
let apiKey = '&appid=bf1b00595f303cce8e0e486ba2929c05';

document.getElementById('generate').addEventListener('click', performAction);

function performAction(e){
    const newZipCode =  document.getElementById('zip').value;
    // const newDate =  document.getElementById('date').value;
    // const newTemp =  document.getElementById('temp').value;
    // const newUserResponse =  document.getElementById('content').value;

    getZipCode(baseURL,newZipCode, apiKey)
    // Create a new date instance dynamically with JS
.then(function(data){
    postData('/addData', {date:data.date, temp: data.temp, user_response:data.user_response} );
    updateUI()
});}
const updateUI = async () => {
    const request = await fetch('/');
    try{
        const allData = await request.json();
        document.getElementById('date').innerHTML = allData[0].date;
        document.getElementById('temp').innerHTML = allData[0].temp;
        document.getElementById('content').innerHTML = allData[0].user_response;

    }catch(error){
        console.log("error", error);
    }
};
const getZipCode = async (baseURL, ZipCode, key)=> {

    const res = await fetch(baseURL + ZipCode + key);
    try {

        const data = await res.json();
        console.log(data);
        return data;
    } catch (error) {
        console.log("error", error);
        // appropriately handle the error
    }};
const postData = async ( url = '', data = {})=>{
    console.log(data);
    const response = await fetch(url, {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
            'Content-Type': 'application/json',
        },
        // Body data type must match "Content-Type" header
        body: JSON.stringify(data),
    });

    try {
        const newData = await response.json();
        console.log(newData);
        return newData;
    }catch(error) {
        console.log("error", error);
    }
};

let d = new Date();
let newDate = d.getMonth()+'.'+ d.getDate()+'.'+ d.getFullYear();